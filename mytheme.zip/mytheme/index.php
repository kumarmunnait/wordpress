<?php get_header(); ?>
asdad

<?php get_footer(); ?>